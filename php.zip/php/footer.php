<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="css/login.css">
</head>
<body>
			<marquee class="marquee" behavior="scroll" direction="left">“Man cannot discover new oceans unless he has the courage to lose sight of the shore.” // “The sea! the sea! the open sea!, The blue, the fresh, the ever free!” // “To me, the sea is like a person–like a child that I’ve known a long time. It sounds crazy, I know, but when I swim in the sea I talk to it. I never feel alone when I’m out there.” // “The ocean stirs the heart, inspires the imagination and brings eternal joy to the soul.” // “No love is Like an ocean with the dizzy procession of the waves’ boundaries …” // “The sea lives in every one of us …” // “Your heart is like the ocean, mysterious and dark.”</marquee>
	<footer>
				<div class="copy"><?=date("Y"); ?> copyright Nicolás ; Bautista ; Franco</div>
				<div class="social">
						<a href="?//http:www.facebook.com" target="_blank"><img src="../imagenes/facebook-logo.png" alt=""></a>
						<a href="?http:www.instagram.com" target="_blank"><img src="../imagenes/instagram-logo.png" alt=""></a>
						<a href="?http:www.twitter.com" target="_blank"><img src="../imagenes/twitter-logo.png" alt=""></a>
				</div>
			</footer>
</body>
</html>
