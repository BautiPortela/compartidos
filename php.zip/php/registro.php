<!DOCTYPE html>
<?php 
require_once("funciones.php");
require_once("soporte.php");
require_once("clases/validadorUsuario.php");
?>
<html>
	<head>
		<link href="https://fonts.googleapis.com/css?family=Audiowide" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/registro.css">
		<title>R e g i s t r o</title>
	</head>
   <?php
    $repoUsuarios = $repo->getRepositorioUsuarios();
    if ($auth->estaLogueado()) {
        header("Location:homeox.php");exit;
    }
    $errores = [];
    $nombreDefault = "";
    $emailDefault = "";
    $userDefault = "";

    if (!empty($_POST))
    {
        $validador = new ValidadorUsuario();
        //Se envió información
        $errores = $validador->validar($_POST, $repo);

        if (empty($errores))
        {
            //No hay Errores

            //Primero: Lo registro
            $usuario = new Usuario(
                null,
                $_POST["nombre"],
                $_POST["email"],
                $_POST["user"],
                $_POST["password"]);
            $usuario->setPassword($_POST["password"]);
            $usuario->guardar($repoUsuarios);
            $usuario->setAvatar($_FILES["images"]);

            //Segundo: Lo envio al exito
            header("Location:homeox.php");exit;


        }

        if (!isset($errores["name"]))
        {
            $nombreDefault = $_POST["name"];
        }
        if (!isset($errores["email"]))
        {
            $emailDefault = $_POST["email"];
        }
		  if (!isset($errores["username"]))
        {
            $userDefault = $_POST["username"];
        }
    }
?>
		<header>
		 	<div class="logo">
	      		<a href=""><img src="imagenes/flor.png" alt="" "></a>
	    	</div>
	  	</header>
		
<?php include("errores.php"); ?>
		
  <div class="container">
		<div class="main">
			<form action="" method="post" enctype="multipart/form-data">
				Nombre: <input type="text" name="nombre" value="" placeholder="Nombre" >
			<br>
			<br>
				Apellido: <input type="text" name="apellido" value="" placeholder="Apellido" >
			<br>
			<br>
				Usuario: <input type="text" name="user" value="" placeholder="Nickname" >
			<br>
			<br>
			<div>
				Seleccionar Imágen de Perfil:
			<input class="images" type="file" name="foto-perfil">
			</div>
			<br>
			<br>
				Email: <input type="email" name="email" value="" placeholder="yo@email.com">
			<br>
			<br>
				Email: <input type="email" name="email-confirm" value="" placeholder="Confirmar E-mail">
			<br>
			<br>
				Contraseña:<input type="password" name="password" value="" placeholder="Contraseña" >
			<br>
			<br>
				Contraseña:<input type="password" name="pass-confirm" value="" placeholder="Confirmar Contraseña" >
			<br>
			<br>
				<a href=""><input type='submit' name='Submit' value='Enviar'></a>
				<button type='reset' name='reset' value='Borrar'>Vaciar
			</form>
		</div>
	</div>
	</body>
</html>
