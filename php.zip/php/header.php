<!DOCTYPE html>
			<html lang="en">
			<head>
				<meta charset="UTF-8">
				<title>Document</title>
				<link rel="stylesheet" href="css/style.css">
			</head>
			<body>
				<header>
					<div class="logo">
						<a href=""><img src="imagenes/flor.png" alt=""></a>
					</div>
					<nav>
						<ul>
							<li><a href="homeox.php">Home</a></li>
							<li><a href="faq.php">FAQ</a></li>
							<li><a href="elset.php">El set</a></li>
							<li><a href="$">Perfil</a></li>
						</ul>
					</nav>
				</header>
			</body>
			</html>			